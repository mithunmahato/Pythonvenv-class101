from netmiko.maipu.maipu import MaipuSSH
from netmiko.maipu.maipu import MaipuTelnet

__all__ = ["MaipuSSH", "MaipuTelnet"]
